# Project: Rust-backed HTML gem to take libxml2 out of Rails' default path

Handoff from a planning chat (2026-10-25). This file is the source of truth for
decisions so far; update it as they change.

## Goal

Every Rails app ships libxml2 (C) via Nokogiri, and libxml2 is a steady source
of CVEs. Since 2025 its sole maintainer treats security reports as ordinary
public bugs and the README calls it foolish to use on untrusted data.
Sanitizing user HTML is exactly that use. Build a Rust-based gem (magnus +
rb-sys, precompiled native gems) covering only what Rails needs.

## Key finding: Rails' dependency is HTML, not XML

- `rails-html-sanitizer` -> Loofah -> Nokogiri: `sanitize`, `strip_tags`,
  Action Text sanitizing. This is what forces Nokogiri into every lockfile
  (1.7.0, Feb 2026, still hard-depends on loofah ~> 2.25 and nokogiri).
- `rails-dom-testing`: `assert_select` / CSS matching (test-time, actionpack).
- Action Text: `ActionText::Fragment`, `html_conversion`, `markdown_conversion`
  find, replace and serialize nodes.
- actionpack `TestResponse#parsed_body` returns a Nokogiri doc for HTML.
- ActiveSupport `XmlMini` defaults to REXML (pure Ruby); Nokogiri is optional.
- Nokogiri's HTML5 parser (gumbo) still builds a libxml2 tree, so the HTML5
  path does not avoid libxml2.

## Scope

In: HTML5 parsing of documents and fragments (html5ever); arena DOM with
traversal and mutation; CSS selectors (Servo `selectors`); a serializer that
matches Nokogiri::HTML5 byte for byte; a sanitizer with Rails' Full / Link /
SafeList semantics.

Out (for now): XPath, XSLT, XSD/RelaxNG/DTD, SAX, the HTML4 quirks parser,
namespace-heavy XML, and any XmlMini backend.

## Phases

1. Inventory the Nokogiri API used by Rails, Loofah, rails-dom-testing and the
   top ~50 gems; that list is the API contract.
2. Core crate + gem: parse, DOM, select, serialize. Differential-test against
   Nokogiri::HTML5 on real HTML (output must match: apps have stored Action
   Text content and snapshot tests).
3. Sanitizer vendor. Seam already exists: rails-html-sanitizer vendor classes,
   `best_supported_vendor`, `config.action_view.sanitizer_vendor`.
4. Action Text + assert_select: actiontext and actionview suites green.
5. Upstream: make Nokogiri optional in rails-html-sanitizer, rails-dom-testing,
   actiontext. Without this the lockfile still pulls libxml2. Needs early
   buy-in from Rails core and Mike Dalessio.

## Open decision (blocks phase 3 design)

A) Drop-in subset of `Nokogiri::HTML5` API so Loofah works unchanged: more
compatible, more work. B) Clean new API plugged in only via the sanitizer
vendor seam: faster, needs more upstream change. Not decided yet.

## Risks

- Custom Loofah scrubbers written against the Nokogiri node API.
- Ruby objects holding Rust nodes across mutation: use `Arc<Document>` + node
  ids, not `Rc` pointers.
- Capybara, SAML libs, Savon, premailer keep Nokogiri in many bundles. Goal is
  "Rails' default path is libxml2-free", not "no app ships libxml2".
- Nokogiri supports non-standard pseudo-classes (`:contains`, jQuery-style);
  existing `assert_select` calls may rely on them.

## Test fixtures (done)

`script/fetch_fixtures` (stdlib Ruby + git) fetches pinned third-party fixtures
into `test/fixtures/`; see `test/fixtures/README.md` for formats and
`NOTICE.md` for sources and licenses. `--verify` is the offline CI check.

- html5lib-tests: tokenizer (6,827), serializer, encoding. Tree-construction
  moved out of this repo.
- wpt: tree-construction `.dat` (1,973 cases), Sanitizer API `.sub.dat`
  (222 cases, html5lib format + `#config` JSON; replace `{{host}}`), selector
  data tables (JS, not JSON yet), fragment-serialization reference tests.
- DOMPurify `expect.json` (223 cases, converted from `expect.mjs` by a
  data-only parser): use payloads as attack inputs; expectations are
  browser-specific.
- Nokogiri, Loofah, rails-html-sanitizer, rails-dom-testing, selected Rails
  tests: behavioral contracts. Loofah's `assets/testdata_sanitizer_tests1.dat`
  records output differences across libxml2 versions.
- Local-only, gitignored (`--include-local`): OWASP XSS cheat sheet
  (CC-BY-SA-4.0), PortSwigger XSS data (no license, redistribution unwelcome).

Property tests to add: sanitize is idempotent; parse -> serialize -> reparse
yields the same tree (catches mXSS-shaped serializer bugs). Give
re-contextualization (output reparsed inside `xmp`, `noscript`, `iframe`,
etc.) its own test class.

## Rules

- Never execute fetched fixture content (no `node`, no `eval`); parse it as data.
- Never commit anything from `test/fixtures/_local/`.
- Change fixtures only via `sources.yml` + `script/fetch_fixtures`.

## Next step

Harness that reads wpt tree-construction and sanitizer-api `.dat` files and
runs them against html5ever, then a data-only extractor for wpt `selectors.js`.
